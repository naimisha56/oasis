package oasis;

import java.util.*;

public class ATM {
    private final Transaction transaction;
    private final Scanner scanner;
    private final User user;
    private Map<String, User> userDatabase;

    public ATM(User user) {
    	this.user=user;
        transaction = new Transaction();
        scanner = new Scanner(System.in);
       
        userDatabase = new HashMap<>();
        userDatabase.put(user.getUserId(), user);
    }
   

    public void run() {
        boolean quit = false;
        while (!quit) {
            showMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            
            switch (choice) {
                case 1:
                    displayTransactionHistory();
                    break;
                case 2:
                    withdraw();
                    break;
                case 3:
                    deposit();
                    break;
                case 4:
                    transfer();
                    break;
                case 5:
                    quit = true;
                    System.out.println("Quitting the ATM. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private void showMenu() {
        System.out.println("ATM Interface");
        System.out.println("1. Transactions History");
        System.out.println("2. Withdraw");
        System.out.println("3. Deposit");
        System.out.println("4. Transfer");
        System.out.println("5. Quit");
        System.out.print("Enter your choice: ");
    }

    private void displayTransactionHistory() {
        System.out.println("Transaction History:");
        for (String transaction : transaction.getTransactionHistory()) {
            System.out.println(transaction);
        }
    }

    private void withdraw() {
        // Implement the withdraw functionality
    	System.out.print("Enter the amount to withdraw: ");
        double amount = scanner.nextDouble();
        
        if (amount > 0 && amount <= user.getBalance()) {
            user.setBalance(user.getBalance() - amount);
            String transactionDetails = "Withdraw: $" + amount;
            transaction.addTransaction(transactionDetails);
            System.out.println("Withdraw successful.");
        } else {
            System.out.println("Invalid amount or insufficient balance.");
        }
    }

    
    private void deposit() {
    	System.out.print("Enter the amount to deposit: ");
        double amount = scanner.nextDouble();
        
        if (amount > 0) {
            user.setBalance(user.getBalance() + amount);
            String transactionDetails = "Deposit: $" + amount;
            transaction.addTransaction(transactionDetails);
            System.out.println("Deposit successful.");
        } else {
            System.out.println("Invalid amount.");
        }
    }
    private void transfer() {
        //System.out.print("Enter the recipient's account number: ");
        String recipientAccountNumber = scanner.nextLine();
        
        System.out.print("Enter the amount to transfer: ");
        double amount = scanner.nextDouble();
        
        if (amount > 0 && amount <= user.getBalance()) {
            
            User recipient = getRecipientUser(recipientAccountNumber); // Implement this method to find the recipient by their account number.
            
            if (recipient != null) {
                user.setBalance(user.getBalance() - amount);
                recipient.setBalance(recipient.getBalance() + amount);
                
                String transactionDetails = "Transfer: $" + amount + " to " + recipient.getUserId();
                transaction.addTransaction(transactionDetails);
                System.out.println("Transfer successful.");
            } else {
                System.out.println("Recipient account not found.");
            }
        } else {
            System.out.println("Invalid amount or insufficient balance.");
        }
    }
    private User getRecipientUser(String recipientAccountNumber) {
        
        if (recipientAccountNumber.equals("user1") || recipientAccountNumber.equals("user2")) {
            return userDatabase.get(recipientAccountNumber);
        } else {
            return null;
        }
    }
}
