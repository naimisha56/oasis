package oasis;
import java.util.Scanner;

import java.util.Scanner;

public class ATMMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Initialize some example users (You can use a database in a real application)
        User user1 = new User("user1", "1234", 1000.0); // Example user with an initial balance of $1000
        User user2 = new User("user2", "5678", 500.0); // Example user with an initial balance of $500
        
        System.out.print("Enter User ID: ");
        String userId = scanner.nextLine();
        
        System.out.print("Enter User PIN: ");
        String pin = scanner.nextLine();
        
        User authenticatedUser = null;
        
        // Check if the entered user ID and PIN match any of the example users
        if (authenticateUser(userId, pin, user1)) {
            authenticatedUser = user1;
        } else if (authenticateUser(userId, pin, user2)) {
            authenticatedUser = user2;
        }
        
        if (authenticatedUser != null) {
            System.out.println("Authentication successful!");
            ATM atm = new ATM(authenticatedUser);
            atm.run();
        } else {
            System.out.println("Authentication failed. Exiting...");
        }
    }
    
    // Function to authenticate the user
    private static boolean authenticateUser(String userId, String pin, User user) {
        return userId.equals(user.getUserId()) && pin.equals(user.getPin());
    }
}
