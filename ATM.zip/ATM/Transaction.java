package oasis;

import java.util.ArrayList;
import java.util.List;

public class Transaction {
    private final List<String> transactionHistory;

    public Transaction() {
        transactionHistory = new ArrayList<>();
    }

    public void addTransaction(String transaction) {
        transactionHistory.add(transaction);
    }

    public List<String> getTransactionHistory() {
        return transactionHistory;
    }
}